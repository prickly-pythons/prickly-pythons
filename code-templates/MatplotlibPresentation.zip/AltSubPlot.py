import matplotlib.pyplot as plt

fig = plt.figure()
# ax1 = fig.add_subplot(221)
# ax2 = fig.add_subplot(222)
ax1 = fig.add_axes([0.5, 0.3, 0.5, 0.3])
plt.show()
